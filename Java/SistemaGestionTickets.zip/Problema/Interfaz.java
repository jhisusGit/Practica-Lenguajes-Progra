package Problema;
import java.awt.FlowLayout;
import javax.swing.*;

public class Interfaz extends JFrame {

    private Cola Cola3raEdad = new Cola();
    private Cola ColaVip = new Cola();
    private Cola ColaNormal = new Cola();
    private String ultimoTipo = "";
    private int consecutivo = 0;

    private JPanel panelPrincipal;
    private JTextField nombreField;
    private JComboBox<String> tipoComboBox;
    private JButton botonAgregar, AtenderSiguiente;
    private JTextArea areaTickets;

    public Interfaz() {
        setTitle("Sistema de Tickets");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        nombreField = new JTextField(20);
        tipoComboBox = new JComboBox<>(new String[]{"3ra Edad", "VIP", "Normal"});
        botonAgregar = new JButton("Agregar Ticket");
        AtenderSiguiente = new JButton("Atender Siguiente");
        areaTickets = new JTextArea(10, 30);
        areaTickets.setEditable(false);

        panelPrincipal.add(new JLabel("Nombre:"));
        panelPrincipal.add(nombreField);
        panelPrincipal.add(new JLabel("Tipo:"));
        panelPrincipal.add(tipoComboBox);
        panelPrincipal.add(botonAgregar);
        panelPrincipal.add(AtenderSiguiente);
        panelPrincipal.add(new JScrollPane(areaTickets));

        add(panelPrincipal);
        setVisible(true);

        botonAgregar.addActionListener(e -> {
            String nombre = nombreField.getText();
            String tipo = (String) tipoComboBox.getSelectedItem();
            Ticket nuevoTicket = new Ticket(nombre, tipo);
            if (tipo.equals("3ra Edad")) {
                Cola3raEdad.enqueue(nuevoTicket);
            } else if (tipo.equals("VIP")) {
                ColaVip.enqueue(nuevoTicket);
            } else if (tipo.equals("Normal")) {
                ColaNormal.enqueue(nuevoTicket);
            }
            areaTickets.append("Ticket agregado: " + nuevoTicket + "\n");
            nombreField.setText("");
        });

        AtenderSiguiente.addActionListener(e -> {
            Ticket atendido = null;

            if (!Cola3raEdad.isEmpty() && (!ultimoTipo.equals("3ra Edad") || consecutivo < 4)) {
                atendido = Cola3raEdad.dequeue(); // sin "Ticket" adelante
                if (ultimoTipo.equals("3ra Edad")) {
                    consecutivo++;
                } else {
                    ultimoTipo = "3ra Edad";
                    consecutivo = 1;
                }
            } else if (!ColaVip.isEmpty() && (!ultimoTipo.equals("VIP") || consecutivo < 2)) {
                atendido = ColaVip.dequeue(); // sin "Ticket" adelante
                if (ultimoTipo.equals("VIP")) {
                    consecutivo++;
                } else {
                    ultimoTipo = "VIP";
                    consecutivo = 1;
                }
            } else if (!ColaNormal.isEmpty() && (!ultimoTipo.equals("Normal") || consecutivo < 3)) {
                atendido = ColaNormal.dequeue(); // sin "Ticket" adelante
                if (ultimoTipo.equals("Normal")) {
                    consecutivo++;
                } else {
                    ultimoTipo = "Normal";
                    consecutivo = 1;
                }
            }

            if (atendido != null) {
                areaTickets.append("Atendiendo a: " + atendido.getNombre() + " (" + atendido.getTipo() + ")\n");
            } else {
                areaTickets.append("No hay tickets disponibles.\n");
            }
        });
    }

    public static void main(String[] args) {
        new Interfaz();
    }
}